# -*- coding: utf-8 -*-
"""دانلود فونت وزیرمتن (Regular / Medium / Bold) داخل assets/fonts؛ یک‌بار روی سیستم خودتان (یا در CI) اجرا کنید.
با داشتن وزن‌های Medium و Bold، تیترها و عددها ریزتر و حرفه‌ای‌تر رندر می‌شوند.
اگر دانلود ناموفق بود با کد خروج ۱ تمام می‌شود تا ساخت انتشار بی‌صدا بدون فونت ادامه پیدا نکند."""
import os, sys, time, urllib.request

BASE = "https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/"
NAMES = ("Vazirmatn-Regular.ttf", "Vazirmatn-Medium.ttf", "Vazirmatn-Bold.ttf")
dest_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "fonts")
os.makedirs(dest_dir, exist_ok=True)

def fetch(name, tries=3):
    dest = os.path.join(dest_dir, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 50_000: print("از قبل هست:", dest); return True
    for i in range(1, tries + 1):
        try:
            urllib.request.urlretrieve(BASE + name, dest)
            if os.path.getsize(dest) > 50_000: print("ذخیره شد:", dest); return True
            raise OSError("فایل دانلودشده کوچک‌تر از حد انتظار است")
        except Exception as ex:
            print(f"تلاش {i} برای {name} ناموفق بود: {ex}", file=sys.stderr); time.sleep(2 * i)
    return False

if __name__ == "__main__":
    ok = all([fetch(n) for n in NAMES])
    sys.exit(0 if ok else 1)
